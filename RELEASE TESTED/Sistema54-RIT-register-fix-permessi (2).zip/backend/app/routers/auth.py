from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, status, UploadFile, File, Query, Request
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.responses import Response, FileResponse
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta, time as dt_time

from .. import models, schemas, database, auth
from ..services import pdf_service, email_service, two_factor_service
from ..utils import get_default_permessi
from ..services.backup_service import (
    list_backups,
    create_backup,
    delete_backup,
    restore_backup,
    get_backup_info,
    get_backup_status,
)

router = APIRouter()


@router.post("/api/auth/login", response_model=schemas.Token, tags=["Autenticazione"])
def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(database.get_db),
    two_factor_code: str = Query(None, description="Codice 2FA per superadmin")
):
    """Login con email e password, con supporto 2FA per superadmin
    
    Se two_factor_code è presente come query parameter, viene usato per verificare 2FA.
    """
    # Verifica se l'utente esiste, altrimenti prova a crearlo
    user_db = db.query(models.Utente).filter(models.Utente.email == form_data.username).first()
    if not user_db:
        # Se non esiste e sono le credenziali di default, crealo
        if form_data.username == "admin@sistema54.it":
            init_superadmin(db)
            user_db = db.query(models.Utente).filter(models.Utente.email == form_data.username).first()
    
    if not user_db:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Email o password non corretti",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    user = auth.authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Email o password non corretti",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Se è superadmin e ha 2FA abilitato, richiedi verifica
    if user.ruolo == models.RuoloUtente.SUPERADMIN and user.two_factor_enabled:
        if not two_factor_code:
            # Richiedi codice 2FA
            return {
                "access_token": "",
                "token_type": "bearer",
                "user": {
                    "id": user.id,
                    "email": user.email,
                    "nome_completo": user.nome_completo,
                    "ruolo": user.ruolo.value
                },
                "requires_2fa": True
            }
        
        # Verifica codice 2FA
        is_valid = False
        updated_backup_codes = user.two_factor_backup_codes or []
        
        # Prova prima con TOTP
        if user.two_factor_secret:
            is_valid = two_factor_service.verify_totp(user.two_factor_secret, two_factor_code)
        
        # Se non valido, prova con backup codes
        if not is_valid and updated_backup_codes:
            is_valid, updated_backup_codes = two_factor_service.verify_backup_code(
                updated_backup_codes, two_factor_code
            )
            if is_valid:
                # Aggiorna backup codes nel database
                user.two_factor_backup_codes = updated_backup_codes
                db.commit()
        
        if not is_valid:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Codice 2FA non valido",
                headers={"WWW-Authenticate": "Bearer"},
            )
    
    access_token_expires = timedelta(minutes=auth.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = auth.create_access_token(
        data={"sub": user.email, "ruolo": user.ruolo.value},
        expires_delta=access_token_expires
    )
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "email": user.email,
            "nome_completo": user.nome_completo,
            "ruolo": user.ruolo.value
        },
        "requires_2fa": False
    }


@router.post("/api/auth/register", response_model=schemas.UserResponse, tags=["Autenticazione"])
def register(
    user_data: schemas.UserCreate,
    db: Session = Depends(database.get_db),
    current_user: models.Utente = Depends(auth.require_admin),
):
    """Registra un nuovo utente (solo admin)"""
    import traceback

    try:
        # Verifica se email esiste già
        existing = db.query(models.Utente).filter(models.Utente.email == user_data.email).first()
        if existing:
            raise HTTPException(status_code=400, detail="Email già registrata")

        # Determina il ruolo (schema usa RuoloUtente, ma accettiamo anche stringhe)
        ruolo_enum = None
        try:
            if isinstance(user_data.ruolo, models.RuoloUtente):
                ruolo_enum = user_data.ruolo
            else:
                ruolo_enum = models.RuoloUtente(str(user_data.ruolo).lower())
        except Exception:
            # fallback sicuro
            ruolo_enum = models.RuoloUtente.OPERATORE

        # Hash password (se qualcosa va storto, lo logghiamo)
        try:
            password_hash = auth.get_password_hash(user_data.password)
        except Exception as e:
            print("❌ Errore hash password in register():", repr(e))
            traceback.print_exc()
            raise HTTPException(status_code=500, detail="Errore hashing password")

        db_user = models.Utente(
            email=user_data.email,
            password_hash=password_hash,
            nome_completo=user_data.nome_completo,
            ruolo=ruolo_enum,
            is_active=True,
            permessi=get_default_permessi(ruolo_enum.value),
        )

        db.add(db_user)
        try:
            db.commit()
        except Exception as e:
            db.rollback()
            print("❌ Errore DB commit in register():", repr(e))
            traceback.print_exc()
            raise HTTPException(status_code=500, detail=f"Errore salvataggio DB: {e}")

        db.refresh(db_user)
        return db_user

    except HTTPException:
        # Lasciamo passare errori applicativi (400/401/403/500 già costruiti)
        raise
    except Exception as e:
        print("❌ Errore imprevisto in register():", repr(e))
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Errore interno durante la registrazione")
@router.get("/api/auth/me", response_model=schemas.UserResponse, tags=["Autenticazione"])
def get_current_user_info(current_user: models.Utente = Depends(auth.get_current_active_user)):
    """Ottiene informazioni sull'utente corrente"""
    return current_user

# --- API 2FA (Solo SuperAdmin) ---


@router.post("/api/auth/2fa/setup", response_model=schemas.TwoFactorSetupResponse, tags=["Autenticazione"])
def setup_2fa(
    current_user: models.Utente = Depends(auth.require_superadmin),
    db: Session = Depends(database.get_db)
):
    """Genera secret e QR code per configurare 2FA (solo superadmin)"""
    if current_user.ruolo != models.RuoloUtente.SUPERADMIN:
        raise HTTPException(status_code=403, detail="Solo i superadmin possono configurare 2FA")
    
    # Genera nuovo secret
    secret = two_factor_service.generate_secret()
    
    # Genera QR code
    qr_code = two_factor_service.generate_qr_code(secret, current_user.email)
    
    # Genera codici di backup
    backup_codes = two_factor_service.generate_backup_codes(10)
    
    # Salva secret e backup codes nel database (ma non abilita ancora 2FA)
    current_user.two_factor_secret = secret
    current_user.two_factor_backup_codes = backup_codes
    db.commit()
    
    return {
        "secret": secret,
        "qr_code": qr_code,
        "backup_codes": backup_codes
    }


@router.post("/api/auth/2fa/enable", tags=["Autenticazione"])
def enable_2fa(
    verify_request: schemas.TwoFactorVerifyRequest,
    current_user: models.Utente = Depends(auth.require_superadmin),
    db: Session = Depends(database.get_db)
):
    """Abilita 2FA dopo aver verificato il codice (solo superadmin)"""
    if current_user.ruolo != models.RuoloUtente.SUPERADMIN:
        raise HTTPException(status_code=403, detail="Solo i superadmin possono abilitare 2FA")
    
    if not current_user.two_factor_secret:
        raise HTTPException(status_code=400, detail="Devi prima configurare 2FA")
    
    # Verifica il codice
    is_valid = two_factor_service.verify_totp(current_user.two_factor_secret, verify_request.code)
    
    if not is_valid:
        raise HTTPException(status_code=400, detail="Codice 2FA non valido")
    
    # Abilita 2FA
    current_user.two_factor_enabled = True
    db.commit()
    
    return {"message": "2FA abilitato con successo"}


@router.post("/api/auth/2fa/disable", tags=["Autenticazione"])
def disable_2fa(
    verify_request: schemas.TwoFactorVerifyRequest,
    current_user: models.Utente = Depends(auth.require_superadmin),
    db: Session = Depends(database.get_db)
):
    """Disabilita 2FA dopo aver verificato il codice (solo superadmin)"""
    if current_user.ruolo != models.RuoloUtente.SUPERADMIN:
        raise HTTPException(status_code=403, detail="Solo i superadmin possono disabilitare 2FA")
    
    if not current_user.two_factor_enabled:
        raise HTTPException(status_code=400, detail="2FA non è abilitato")
    
    # Verifica il codice prima di disabilitare
    is_valid = False
    if current_user.two_factor_secret:
        is_valid = two_factor_service.verify_totp(current_user.two_factor_secret, verify_request.code)
    
    # Se non valido, prova con backup codes
    if not is_valid and current_user.two_factor_backup_codes:
        is_valid, _ = two_factor_service.verify_backup_code(
            current_user.two_factor_backup_codes, verify_request.code
        )
    
    if not is_valid:
        raise HTTPException(status_code=400, detail="Codice 2FA non valido")
    
    # Disabilita 2FA
    current_user.two_factor_enabled = False
    current_user.two_factor_secret = None
    current_user.two_factor_backup_codes = None
    db.commit()
    
    return {"message": "2FA disabilitato con successo"}


@router.post("/api/auth/2fa/regenerate-backup", tags=["Autenticazione"])
def regenerate_backup_codes(
    current_user: models.Utente = Depends(auth.require_superadmin),
    db: Session = Depends(database.get_db)
):
    """Rigenera codici di backup per 2FA (solo superadmin)"""
    if current_user.ruolo != models.RuoloUtente.SUPERADMIN:
        raise HTTPException(status_code=403, detail="Solo i superadmin possono rigenerare backup codes")
    
    if not current_user.two_factor_enabled:
        raise HTTPException(status_code=400, detail="2FA non è abilitato")
    
    # Genera nuovi backup codes
    backup_codes = two_factor_service.generate_backup_codes(10)
    current_user.two_factor_backup_codes = backup_codes
    db.commit()
    
    return {"backup_codes": backup_codes}


@router.post("/api/auth/oauth", response_model=schemas.Token, tags=["Autenticazione"])
def oauth_login(oauth_data: schemas.OAuthLoginRequest, db: Session = Depends(database.get_db)):
    """Login con OAuth (Google, Microsoft) - Placeholder per implementazione futura"""
    # TODO: Implementare verifica token OAuth
    raise HTTPException(status_code=501, detail="OAuth non ancora implementato")

# --- API UTENTI (Solo Admin) ---

