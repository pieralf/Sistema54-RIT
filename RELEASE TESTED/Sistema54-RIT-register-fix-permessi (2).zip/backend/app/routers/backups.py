from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, status, UploadFile, File, Query, Request
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.responses import Response, FileResponse
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta, time as dt_time

from .. import models, schemas, database, auth
from ..services import pdf_service, email_service, two_factor_service
from ..services.backup_service import (
    list_backups,
    create_backup,
    delete_backup,
    restore_backup,
    get_backup_info,
    get_backup_status,
)

router = APIRouter()


@router.get("/api/backups/", response_model=List[schemas.BackupInfo], tags=["Backup"])
def get_backups(
    db: Session = Depends(database.get_db),
    current_user: models.Utente = Depends(auth.require_superadmin)
):
    """Ottiene la lista di tutti i backup disponibili"""
    try:
        backups = list_backups()
        return backups
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Errore durante il recupero dei backup: {str(e)}")


@router.get("/api/backups/status", response_model=schemas.BackupStatusResponse, tags=["Backup"])
def get_backup_status_endpoint(
    db: Session = Depends(database.get_db),
    current_user: models.Utente = Depends(auth.require_superadmin)
):
    """Ottiene lo stato corrente del backup"""
    try:
        status = get_backup_status()
        return status
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Errore durante il recupero dello stato: {str(e)}")


@router.get("/api/backups/{backup_id}", response_model=schemas.BackupInfo, tags=["Backup"])
def get_backup(
    backup_id: str,
    db: Session = Depends(database.get_db),
    current_user: models.Utente = Depends(auth.require_superadmin)
):
    """Ottiene informazioni dettagliate su un backup specifico"""
    backup_info = get_backup_info(backup_id)
    if not backup_info:
        raise HTTPException(status_code=404, detail="Backup non trovato")
    return backup_info


@router.post("/api/backups/create", response_model=schemas.BackupCreateResponse, tags=["Backup"])
def create_backup_endpoint(
    background_tasks: BackgroundTasks,
    request: Request,
    db: Session = Depends(database.get_db),
    current_user: models.Utente = Depends(auth.require_superadmin)
):
    """Crea un nuovo backup completo"""
    try:
        # Log audit (usiamo 0 come ID placeholder per i backup che non hanno un ID nel database)
        log_action(
            db=db,
            user=current_user,
            action="CREATE",
            entity_type="backup",
            entity_id=0,
            entity_name="Backup completo",
            ip_address=get_client_ip(request)
        )
        
        result = create_backup(background=True, db=db)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Errore durante la creazione del backup: {str(e)}")


@router.delete("/api/backups/{backup_id}", tags=["Backup"])
def delete_backup_endpoint(
    backup_id: str,
    request: Request,
    db: Session = Depends(database.get_db),
    current_user: models.Utente = Depends(auth.require_superadmin)
):
    """Elimina un backup"""
    try:
        delete_backup(backup_id)
        
        # Log audit (usiamo 0 come ID placeholder per i backup che non hanno un ID nel database)
        log_action(
            db=db,
            user=current_user,
            action="DELETE",
            entity_type="backup",
            entity_id=0,
            entity_name=backup_id,
            ip_address=get_client_ip(request)
        )
        
        return {"message": "Backup eliminato con successo"}
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Backup non trovato")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Errore durante l'eliminazione del backup: {str(e)}")


@router.get("/api/backups/{backup_id}/download", tags=["Backup"])
def download_backup(
    backup_id: str,
    db: Session = Depends(database.get_db),
    current_user: models.Utente = Depends(auth.require_superadmin)
):
    """Scarica un file di backup"""
    from pathlib import Path
    
    backup_dir = Path("backups")
    backup_file = backup_dir / backup_id
    
    if not backup_file.exists():
        raise HTTPException(status_code=404, detail="Backup non trovato")
    
    return FileResponse(
        path=str(backup_file),
        filename=backup_id,
        media_type="application/octet-stream"
    )


@router.post("/api/backups/{backup_id}/restore", response_model=schemas.BackupRestoreResponse, tags=["Backup"])
def restore_backup_endpoint(
    backup_id: str,
    restore_request: schemas.BackupRestoreRequest,
    request: Request,
    db: Session = Depends(database.get_db),
    current_user: models.Utente = Depends(auth.require_superadmin)
):
    """Ripristina un backup"""
    try:
        # Log audit (usiamo 0 come ID placeholder per i backup che non hanno un ID nel database)
        log_action(
            db=db,
            user=current_user,
            action="RESTORE",
            entity_type="backup",
            entity_id=0,
            entity_name=f"{backup_id} (tipo: {restore_request.restore_type})",
            ip_address=get_client_ip(request)
        )
        
        result = restore_backup(backup_id, restore_request.restore_type)
        return result
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Errore durante il ripristino: {str(e)}")


@router.post("/api/backups/upload-restore", response_model=schemas.BackupRestoreResponse, tags=["Backup"])
def upload_and_restore_backup(
    file: UploadFile = File(...),
    restore_type: str = Query("full", description="Tipo di ripristino: full, database, volumes, config"),
    request: Request = None,
    db: Session = Depends(database.get_db),
    current_user: models.Utente = Depends(auth.require_superadmin)
):
    """Carica un file di backup e lo ripristina"""
    from pathlib import Path
    
    try:
        # Verifica estensione file
        if not file.filename.endswith(('.tar.gz', '.zip')):
            raise HTTPException(status_code=400, detail="Il file deve essere un backup valido (.tar.gz o .zip)")
        
        # Salva il file temporaneamente nella directory backups
        backup_dir = Path("backups")
        backup_dir.mkdir(exist_ok=True)
        
        # Genera nome file univoco
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        uploaded_filename = f"uploaded_backup_{timestamp}_{file.filename}"
        backup_file_path = backup_dir / uploaded_filename
        
        # Salva il file
        with open(backup_file_path, "wb") as f:
            shutil.copyfileobj(file.file, f)
        
        # Log audit
        log_action(
            db=db,
            user=current_user,
            action="RESTORE",
            entity_type="backup",
            entity_id=0,
            entity_name=f"{uploaded_filename} (tipo: {restore_type}, upload)",
            ip_address=get_client_ip(request) if request else None
        )
        
        # Ripristina il backup
        result = restore_backup(uploaded_filename, restore_type)
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Errore durante il caricamento e ripristino: {str(e)}")
