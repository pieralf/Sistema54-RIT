"""
Servizio per gestione backup Sistema54
Esegue backup completi (database + volumi + configurazione)
"""

import subprocess
import os
import json
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime
import platform
from sqlalchemy.orm import Session
import time

# Configurazione
PROJECT_ROOT = Path(__file__).parent.parent.parent
BACKUP_DIR = PROJECT_ROOT / "backups"
BACKUP_SCRIPT_DIR = PROJECT_ROOT / "backup"
BACKUP_STATUS_FILE = BACKUP_DIR / "backup_status.json"

# Verifica se siamo su Windows o Linux/Mac
IS_WINDOWS = platform.system() == "Windows"

def get_backup_config(db: Session) -> Dict:
    """Recupera la configurazione backup dal database"""
    from .. import models
    
    settings = db.query(models.ImpostazioniAzienda).first()
    if not settings:
        return {
            "nas_enabled": False,
            "nas_path": None,
            "cloud_enabled": False,
            "cloud_provider": None,
            "keep_count": 10
        }
    
    return {
        "nas_enabled": settings.backup_nas_enabled or False,
        "nas_path": settings.backup_nas_path,
        "cloud_enabled": settings.backup_cloud_enabled or False,
        "cloud_provider": settings.backup_cloud_provider,
        "keep_count": settings.backup_keep_count or 10
    }

def get_backup_script_path() -> Path:
    """Restituisce il percorso dello script di backup appropriato"""
    if IS_WINDOWS:
        return BACKUP_SCRIPT_DIR / "backup_complete.ps1"
    else:
        return BACKUP_SCRIPT_DIR / "backup_complete.sh"

def get_restore_script_path() -> Path:
    """Restituisce il percorso dello script di ripristino appropriato"""
    if IS_WINDOWS:
        return BACKUP_SCRIPT_DIR / "restore_complete.ps1"
    else:
        return BACKUP_SCRIPT_DIR / "restore_complete.sh"

def list_backups() -> List[Dict]:
    """Lista tutti i backup disponibili"""
    backups = []
    
    if not BACKUP_DIR.exists():
        return backups
    
    # Cerca file di backup (tar.gz o zip)
    backup_files = list(BACKUP_DIR.glob("sistema54_complete_backup_*.tar.gz"))
    backup_files.extend(BACKUP_DIR.glob("sistema54_complete_backup_*.zip"))
    
    for backup_file in sorted(backup_files, key=lambda x: x.stat().st_mtime, reverse=True):
        stat = backup_file.stat()
        size_mb = stat.st_size / (1024 * 1024)
        
        # Estrai timestamp dal nome file
        timestamp_str = backup_file.stem.replace("sistema54_complete_backup_", "")
        try:
            timestamp = datetime.strptime(timestamp_str, "%Y%m%d_%H%M%S")
        except:
            timestamp = datetime.fromtimestamp(stat.st_mtime)
        
        backups.append({
            "id": backup_file.name,
            "filename": backup_file.name,
            "path": str(backup_file),
            "size_mb": round(size_mb, 2),
            "size_bytes": stat.st_size,
            "created_at": timestamp.isoformat(),
            "created_at_readable": timestamp.strftime("%d/%m/%Y %H:%M:%S")
        })
    
    return backups

def write_backup_status(status: str, progress: int, message: str = "", error: str = ""):
    """Scrive lo stato del backup in un file JSON"""
    status_data = {
        "status": status,  # "running", "completed", "error"
        "progress": progress,  # 0-100
        "message": message,
        "error": error,
        "timestamp": datetime.now().isoformat()
    }
    try:
        BACKUP_DIR.mkdir(exist_ok=True)
        with open(BACKUP_STATUS_FILE, "w") as f:
            json.dump(status_data, f, indent=2)
    except Exception as e:
        print(f"Errore scrittura stato backup: {e}")

def get_backup_status() -> Dict:
    """Legge lo stato del backup dal file JSON"""
    if not BACKUP_STATUS_FILE.exists():
        return {
            "status": "idle",
            "progress": 0,
            "message": "",
            "error": "",
            "timestamp": None
        }
    
    try:
        with open(BACKUP_STATUS_FILE, "r") as f:
            return json.load(f)
    except Exception as e:
        return {
            "status": "error",
            "progress": 0,
            "message": "",
            "error": f"Errore lettura stato: {str(e)}",
            "timestamp": None
        }

def create_backup(background: bool = True, db: Optional[Session] = None) -> Dict:
    """Crea un nuovo backup completo"""
    script_path = get_backup_script_path()
    
    if not script_path.exists():
        raise FileNotFoundError(f"Script di backup non trovato: {script_path}")
    
    # Inizializza lo stato del backup
    write_backup_status("running", 0, "Avvio backup...")
    
    # Prepara variabili d'ambiente dalla configurazione database
    env = os.environ.copy()
    if db:
        try:
            config = get_backup_config(db)
            if config.get("nas_enabled") and config.get("nas_path"):
                env["NAS_PATH"] = config["nas_path"]
            if config.get("cloud_enabled") and config.get("cloud_provider"):
                env["CLOUD_PROVIDER"] = config["cloud_provider"]
            if config.get("keep_count"):
                env["KEEP_BACKUPS"] = str(config["keep_count"])
            if config.get("local_path"):
                # Converte percorso Windows in percorso Linux montato
                local_path = config["local_path"]
                # Se è un percorso Windows come C:\Backup, convertilo in /mnt/backup-local
                if local_path.startswith("C:\\") or local_path.startswith("C:/"):
                    # Estrai il nome della cartella dopo C:\
                    folder_name = local_path.replace("C:\\", "").replace("C:/", "").replace("\\", "/")
                    if folder_name == "Backup":
                        env["LOCAL_PATH"] = "/mnt/backup-local"
                    else:
                        # Per altri percorsi, prova a montarli manualmente o usa il percorso relativo
                        env["LOCAL_PATH"] = local_path
                else:
                    env["LOCAL_PATH"] = local_path
        except Exception as e:
            # Se c'è un errore nel recupero della configurazione, continua senza
            print(f"Avviso: impossibile recuperare configurazione backup: {e}")
    
    if background:
        # Esegui in background
        if IS_WINDOWS:
            process = subprocess.Popen(
                ["powershell", "-ExecutionPolicy", "Bypass", "-File", str(script_path)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=str(PROJECT_ROOT),
                env=env
            )
        else:
            process = subprocess.Popen(
                ["bash", str(script_path)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=str(PROJECT_ROOT),
                env=env
            )
        
        return {
            "status": "started",
            "pid": process.pid,
            "message": "Backup avviato in background"
        }
    else:
        # Esegui in foreground (bloccante)
        if IS_WINDOWS:
            result = subprocess.run(
                ["powershell", "-ExecutionPolicy", "Bypass", "-File", str(script_path)],
                capture_output=True,
                text=True,
                cwd=str(PROJECT_ROOT),
                env=env
            )
        else:
            result = subprocess.run(
                ["bash", str(script_path)],
                capture_output=True,
                text=True,
                cwd=str(PROJECT_ROOT),
                env=env
            )
        
        if result.returncode == 0:
            return {
                "status": "completed",
                "message": "Backup completato con successo",
                "output": result.stdout
            }
        else:
            return {
                "status": "error",
                "message": "Errore durante il backup",
                "error": result.stderr
            }

def delete_backup(backup_id: str) -> bool:
    """Elimina un backup"""
    backup_file = BACKUP_DIR / backup_id
    
    if not backup_file.exists():
        raise FileNotFoundError(f"Backup non trovato: {backup_id}")
    
    try:
        backup_file.unlink()
        return True
    except Exception as e:
        raise Exception(f"Errore durante l'eliminazione: {str(e)}")

def restore_backup(backup_id: str, restore_type: str = "full") -> Dict:
    """Ripristina un backup"""
    script_path = get_restore_script_path()
    backup_file = BACKUP_DIR / backup_id
    
    if not script_path.exists():
        raise FileNotFoundError(f"Script di ripristino non trovato: {script_path}")
    
    if not backup_file.exists():
        raise FileNotFoundError(f"Backup non trovato: {backup_id}")
    
    # Costruisci comando di ripristino
    if IS_WINDOWS:
        cmd = [
            "powershell", "-ExecutionPolicy", "Bypass", "-File", str(script_path),
            "-BackupFile", str(backup_file)
        ]
        
        if restore_type == "database":
            cmd.append("-DatabaseOnly")
        elif restore_type == "volumes":
            cmd.append("-VolumesOnly")
        elif restore_type == "config":
            cmd.append("-ConfigOnly")
    else:
        cmd = ["bash", str(script_path), str(backup_file)]
        
        if restore_type == "database":
            cmd.append("--database-only")
        elif restore_type == "volumes":
            cmd.append("--volumes-only")
        elif restore_type == "config":
            cmd.append("--config-only")
    
    # Esegui ripristino in background
    if IS_WINDOWS:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=str(PROJECT_ROOT)
        )
    else:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=str(PROJECT_ROOT)
        )
    
    return {
        "status": "started",
        "pid": process.pid,
        "message": f"Ripristino avviato (tipo: {restore_type})"
    }

def get_backup_info(backup_id: str) -> Optional[Dict]:
    """Ottiene informazioni dettagliate su un backup"""
    backup_file = BACKUP_DIR / backup_id
    
    if not backup_file.exists():
        return None
    
    stat = backup_file.stat()
    size_mb = stat.st_size / (1024 * 1024)
    
    # Estrai timestamp dal nome file
    timestamp_str = backup_file.stem.replace("sistema54_complete_backup_", "")
    try:
        timestamp = datetime.strptime(timestamp_str, "%Y%m%d_%H%M%S")
    except:
        timestamp = datetime.fromtimestamp(stat.st_mtime)
    
    return {
        "id": backup_id,
        "filename": backup_file.name,
        "path": str(backup_file),
        "size_mb": round(size_mb, 2),
        "size_bytes": stat.st_size,
        "created_at": timestamp.isoformat(),
        "created_at_readable": timestamp.strftime("%d/%m/%Y %H:%M:%S"),
        "exists": True
    }

